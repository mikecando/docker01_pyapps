killall -9 firefox;
killall -9 firefox-bin;
killall -9 chromedriver;
killall -9 "Google Chrome";
chromedriver --version
