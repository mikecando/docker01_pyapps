#Enter Your Credentials Here
#poshmark_username = "poshmarkusername"
#poshmark_password = "poshmarkpassword"

#Rename this file "credentials.py"
#mv example_credentials.py credentials.py
